#!/usr/bin/env node
/**
 * update-index-toc.js
 * Updates the landing page (index.md) with the detailed table of contents.
 */
const fs = require('fs');
const path = require('path');

const slug = process.argv[2];
const tocMarkdown = process.argv[3];

if (!slug || !tocMarkdown) {
  console.error('Usage: node update-index-toc.js <slug> "<toc_markdown>"');
  process.exit(1);
}

const indexPath = path.join('/home/node/openclaw/books', slug, 'index.md');

if (!fs.existsSync(indexPath)) {
  console.error('Index file not found:', indexPath);
  process.exit(1);
}

let content = fs.readFileSync(indexPath, 'utf8');

// Insert the TOC after the book cover figure or before the chapter grid
const tocSection = `\n## Table of Contents\n\n${tocMarkdown}\n`;

if (content.includes('## Table of Contents')) {
  // Replace existing
  content = content.replace(/## Table of Contents[\s\S]*?(?=\n##|$)/, tocSection.trim());
} else {
  // Append after cover or before Grid
  if (content.includes(':::')) {
      const parts = content.split(':::');
      // Insert after the second ::: (the end of the figure)
      parts[2] = tocSection + parts[2];
      content = parts.join(':::');
  } else {
      content += tocSection;
  }
}

fs.writeFileSync(indexPath, content);
console.log('Index landing page updated with detailed Table of Contents.');
